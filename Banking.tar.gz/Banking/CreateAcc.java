package Banking;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static jdk.nashorn.internal.objects.Global.print;

public class CreateAcc {
private String fname,lname,type,dob;
private long phoneNo,aadharNo;
private int doorNo,stNo;
ArrayList<CreateAcc> accountlist=new ArrayList<>();

    public int getDoorNo() {
        return doorNo;
    }

    public void setDoorNo(int doorNo) {
        this.doorNo = doorNo;
    }

    public int getStNo() {
        return stNo;
    }

    public void setStNo(int stNo) {
        this.stNo = stNo;
    }

    public String getStName() {
        return stName;
    }

    public void setStName(String stName) {
        this.stName = stName;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDist() {
        return dist;
    }

    public void setDist(String dist) {
        this.dist = dist;
    }

    private String stName,area,dist;

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    float bal=0;

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    int aNumber;
public String toString(){
    return fname+" "+" "+lname+" "+type+" "+" "+aNumber+" "+phoneNo;
}
    public long getPhoneNo() {
        return phoneNo;
    }
    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }
    public long getAadharNo() {
        return aadharNo;
    }
    public void setAadharNo(long aadharNo) {
        this.aadharNo = aadharNo;
    }
    public float getBal() {
        return bal;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setBal(float bal) {
        this.bal = bal;
    }

    public int getaNumber() {
        return aNumber;
    }

    public void setaNumber(int aNumber) {
        this.aNumber = aNumber;
    }



    public void newAcc() {
        CreateAcc a1 = new CreateAcc();
        Scanner scn1 = new Scanner(System.in);
        System.out.println("Enter the type of account to create\n" +
                "1:savings bank account\n2:current account");
        int ch2 = scn1.nextInt();
        while (!(ch2 == 1 || ch2 == 2)) {
            System.out.println("invalid choice enter again");
            ch2 = scn1.nextInt();
        }
        if (ch2 == 1) type = "savings bank account";

        if (ch2 == 2) type = "current account";
        //break;

        System.out.println(type);
        a1.setType(type);
        Scanner scn = new Scanner(System.in);
System.out.println("Enter your first name");
        fname = scn.nextLine();
        while(!fname.matches("[a-zA-Z_]+"))
        {
            System.out.println("Enter a valid first name");
            fname = scn.nextLine();
        }
        a1.setFname(fname);
        System.out.println("Enter your last name");
        lname = scn.nextLine();
        while(!lname.matches("[a-zA-Z_]+"))
        {
            System.out.println("Enter a valid last name");
            lname = scn.nextLine();
        }
        a1.setLname(lname);
/*    System.out.println("enter your date of birth in format dd/mm/yyyy");
        Scanner inss = new Scanner(System.in);
        SimpleDateFormat df = new SimpleDateFormat("dd/mm/yyyy");
        Date testDate= null;
        do {
                System.out.println("enter date");
            dob = inss.nextLine();
            try { testDate = df.parse(dob);
                           }catch (ParseException e) {
                System.out.println("invalid format");
                 } }
       while (!df.format(testDate).equals(dob) );*/

        System.out.println("enter your date of birth in format dd-mm-yyyy");
        Scanner ins = new Scanner(System.in);
       do{
           System.out.println("enter date");
           dob = ins.nextLine();
           }
        while(!dob.matches("^(0?[1-9]|[12][0-9]|3[01])-(0?[1-9]|1[012])-([1-9][0-9][0-9][0-9])$"));
        a1.setDob(dob);


  boolean flag=true;
  do{   try{
       System.out.println("enter your address.....door number");
                     String  str=scn.next();
      doorNo = Integer.parseInt(str);
                flag=false;
            }
        catch(Exception e){    // catch (Exception e) {
            System.out.println("invalid ..try again");
           flag=true;
                       }}while(flag);
                a1.setDoorNo(doorNo);
     do{try{
               System.out.println("enter your street number");
               String  str=scn.next();
               stNo = Integer.parseInt(str);
               flag=false;}
           catch(Exception e){
               System.out.println("invalid ..try again");
               flag=true;
           }}while(flag);
            a1.setStNo(stNo);
                   Scanner in = new Scanner(System.in);
            System.out.println("enter your street name");
            stName = in.nextLine();
        while(!stName.matches("[a-zA-Z_]+"))
        {
            System.out.println("Enter a valid street name");
            stName = in.nextLine();
        }            a1.setStName(stName);

            System.out.println("enter your area");
            area = in.nextLine();
        while(!area.matches("[a-zA-Z_]+"))
        {
            System.out.println("Enter a valid area");
            area = in.nextLine();
        }
            a1.setArea(area);
            System.out.println("enter your district");
            dist = in.nextLine();
        while(!dist.matches("[a-zA-Z_]+"))
        {
            System.out.println("Enter a valid district name");
            dist = in.nextLine();
        }
            a1.setDist(dist);


 boolean flag4=true;
 do {
            try{

                System.out.println("enter your 10 digit phone number");
                String  str=scn.next();
              phoneNo = Long.parseLong(str);
              flag4=false; }
catch(Exception e){
    System.out.println("invalid phno type..try again");
    flag4=true;     }

 }while (flag4 || (phoneNo >= 9999999999L || phoneNo <= 1111111111L));
a1.setPhoneNo(phoneNo);

    boolean flag1=true;
            do {
           try {
               System.out.println("enter your 12 digit aadhar number");
               String str1 = scn.next();
               aadharNo = Long.parseLong(str1);
               flag1 = false;
           } catch (Exception e) {
               System.out.println("invalid");
               flag1= true;
           }
       }while(flag1 ||(aadharNo >= 999999999999L || aadharNo <= 111111111111L) );
a1.setAadharNo(aadharNo);

        if (getType() == "savings bank account") {

            boolean flag2 = true;
            do {
                try {
                    System.out.println("enter your initial deposit amount");
                    String str2 = scn1.next();
                    bal = Float.parseFloat(str2);
                    flag2 = false;
                } catch (Exception e) {
                    System.out.println("invalid amount..try again");
                    flag2 = true;
                }
            } while (flag2);
            a1.setBal(bal);

            aNumber = (int) ((Math.random() * 9000) + 1000);
            a1.setaNumber(aNumber);
            accountlist.add(a1);
            System.out.println("Account created for  " + a1.getFname() + " " + a1.getLname() + "  acc no is " + a1.getaNumber() + " bal is " + a1.getBal());
        }
        if (getType() == "current account") {

            boolean flag2 = true;
            do {
                try {
                    System.out.println("enter your initial deposit amount above 1000");
                    String str2 = scn1.next();
                    bal = Float.parseFloat(str2);
                    flag2 = false;
                } catch (Exception e) {
                    System.out.println("invalid amount..try again");
                    flag2 = true;
                }
            } while (flag2||bal<1000);
            a1.setBal(bal);

            aNumber = (int) ((Math.random() * 9000) + 1000);
            a1.setaNumber(aNumber);
            accountlist.add(a1);
            System.out.println("Account created for  " + a1.getFname() + " " + a1.getLname() + "  acc no is " + a1.getaNumber() + " bal is " + a1.getBal());
        }


    }
public void deposite(int accountno) {
      //for (int i = 0; i < 10; i++) {
        CreateAcc a1=new CreateAcc();
        for (CreateAcc a: accountlist) {
            if (a.getaNumber()==accountno)
            {
                a1=a;
                break;
        }
        }
               if ( a1.getaNumber()== accountno) {
                System.out.println("enter amount to be deposited");
                Scanner scn1 = new Scanner(System.in);
                float damt = scn1.nextFloat();
                bal = a1.getBal();
                System.out.println("old balance"+bal);
                bal = bal + damt;
                a1.setBal(bal);
                System.out.println("new balance"+getBal());
            }
            else
            {
                System.out.println("invalid account");
                            }
        }


public void details(int accountno) {
    CreateAcc a = new CreateAcc();
    for (CreateAcc a1 : accountlist
            ) {
        if (a1.getaNumber() == accountno) {
            a = a1;
            break;
        }
    }
    if (a.getaNumber() == accountno) {
    System.out.println("Account creator name  " + a.fname + " " + a.lname + "\nacc no is " + a.aNumber
            + "\naccount type: " + a.type + " \nbal is " + a.bal);
    System.out.println("phone num " + a.phoneNo + " \naadhar number " + a.aadharNo + " \naddress:\n#" + a.doorNo + "," + a.stNo + "," +
            a.stName + "," + a.area + "," + a.dist + "\ndate of birth " + a.dob);
}
else
        System.out.println("invalid acccount");
        }

public void withdraw(int accountno) {
CreateAcc a1=new CreateAcc();
        for (CreateAcc a: accountlist) {
if (a.getaNumber() == accountno) {
    a1 = a;
    break;
}}
            if (a1.getaNumber() == accountno) {
                System.out.println("enter amount to be withdrawn ");
                Scanner scn1 = new Scanner(System.in);
                float wamt = scn1.nextFloat();
                bal = a1.getBal();
                System.out.println("old balance" + bal);
                if (wamt >= bal) {
                    System.out.println("your account is out of balance " + "and the balance is " + a1.getBal());
                } else {
                    bal = bal - wamt;
                    a1.setBal(bal);
                    System.out.println("new balance after withdraw " + a1.getBal());
                } }
                else
                    System.out.println("inavlid account number");

    }
}
