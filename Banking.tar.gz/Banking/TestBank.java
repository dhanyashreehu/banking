package Banking;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import static java.lang.System.exit;
import static jdk.nashorn.internal.objects.Global.print;

public class TestBank {

    public static void main(String[] args)
{
         System.out.println("welcome to the banking application" );
  //CreateAcc a1[]=new CreateAcc[10];
        CreateAcc a1=new CreateAcc();
         for(int i=0;i<10;i++)
         {
              System.out.println("\nSelect your choice\n" +
             "1:Create Bank account\n2:Deposit amount\n3:Withdraw amount\n4:View details\n5: EXIT\n");
    Scanner sc=new Scanner(System.in);
  int choice=sc.nextInt();
 // a1[i]=new CreateAcc();

            switch (choice)
       {
           case 1:{
               System.out.println("creating new bank account");
             a1.newAcc();

             break;
           }
           case 2:{
               System.out.println("deposition");
               System.out.println("enter your account number");
               int accno=sc.nextInt();

               a1.deposite(accno);
                break;
           }
           case 3:{
               System.out.println("withdrawal");
               System.out.println("enter your account number");
               int accountno=sc.nextInt();
               a1.withdraw(accountno);

break;
           }
           case 4: {
               System.out.println("the details are");
               System.out.println("enter your account number");
               int accountno=sc.nextInt();
               a1.details(accountno);

break;
           }
           case 5:exit(0);
           default:System.out.println("enter valid option");
       }

         }
    }
}
